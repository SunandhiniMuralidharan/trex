/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "../../../../../../../../DevEcoStudioProjects/OpenHarmonyUtilCode/entry/src/main/ets/MainAbility/pages/CleanUtilsSample.ets?entry":
/*!****************************************************************************************************************************************!*\
  !*** ../../../../../../../../DevEcoStudioProjects/OpenHarmonyUtilCode/entry/src/main/ets/MainAbility/pages/CleanUtilsSample.ets?entry ***!
  \****************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
/*
* Copyright (C) 2022 Application library engineering group.
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
const utilcode_1 = __webpack_require__(/*! @ohos/utilcode */ "../../../../../../../../DevEcoStudioProjects/OpenHarmonyUtilCode/utilcode/index.ets");
var _system_prompt_1  = isSystemplugin('prompt', 'system') ? globalThis.systemplugin.prompt : globalThis.requireNapi('prompt');
var _ohos_data_storage_1  = globalThis.requireNapi('data.storage') || (isSystemplugin('data.storage', 'ohos') ? globalThis.ohosplugin.data.storage : isSystemplugin('data.storage', 'system') ? globalThis.systemplugin.data.storage : undefined);
var _ohos_ability_featureAbility_1  = globalThis.requireNapi('ability.featureAbility') || (isSystemplugin('ability.featureAbility', 'ohos') ? globalThis.ohosplugin.ability.featureAbility : isSystemplugin('ability.featureAbility', 'system') ? globalThis.systemplugin.ability.featureAbility : undefined);
var _ohos_data_rdb_1  = globalThis.requireNapi('data.rdb') || (isSystemplugin('data.rdb', 'ohos') ? globalThis.ohosplugin.data.rdb : isSystemplugin('data.rdb', 'system') ? globalThis.systemplugin.data.rdb : undefined);
const STORE_CONFIG = { name: 'book.db' };
const SQL_CREATE_TABLE = 'CREATE TABLE IF NOT EXISTS book(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, introduction TEXT NOT NULL)';
class Index extends View {
    constructor(compilerAssignedUniqueChildId, parent, params) {
        super(compilerAssignedUniqueChildId, parent);
        this.__data = new ObservedPropertySimple('path', this, "data");
        this.__dbText = new ObservedPropertySimple("", this, "dbText");
        this.__dirText = new ObservedPropertySimple("", this, "dirText");
        this.index = new utilcode_1.CleanUtils();
        this.updateWithValueParams(params);
    }
    updateWithValueParams(params) {
        if (params.data !== undefined) {
            this.data = params.data;
        }
        if (params.dbText !== undefined) {
            this.dbText = params.dbText;
        }
        if (params.dirText !== undefined) {
            this.dirText = params.dirText;
        }
        if (params.index !== undefined) {
            this.index = params.index;
        }
    }
    aboutToBeDeleted() {
        this.__data.aboutToBeDeleted();
        this.__dbText.aboutToBeDeleted();
        this.__dirText.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id());
    }
    get data() {
        return this.__data.get();
    }
    set data(newValue) {
        this.__data.set(newValue);
    }
    get dbText() {
        return this.__dbText.get();
    }
    set dbText(newValue) {
        this.__dbText.set(newValue);
    }
    get dirText() {
        return this.__dirText.get();
    }
    set dirText(newValue) {
        this.__dirText.set(newValue);
    }
    aboutToAppear() {
        var context = _ohos_ability_featureAbility_1.getContext();
        context.getFilesDir((err, path) => {
            if (err) {
                console.error('getFilesDir failed. err: ' + JSON.stringify(err));
                return;
            }
            this.data = path;
            let storage = _ohos_data_storage_1.getStorageSync(path + '/sharedPreference');
            var observer = function (key) {
                console.info("The key of " + key + " changed.");
            };
            storage.on('change', observer);
            storage.putSync('startup', 'auto');
            storage.flushSync();
            storage.off('change', observer);
        });
        let promise = _ohos_data_rdb_1.getRdbStore(this, STORE_CONFIG, 1);
        promise.then(async (rdbStore) => {
            await rdbStore.executeSql(SQL_CREATE_TABLE, null);
        }).catch((err) => {
            console.info('Error in obtaining RDB Store: ' + err.message);
        });
    }
    cleanInternalCache() {
        this.index.cleanInternalCache().then((path) => {
            this.data = path;
            _system_prompt_1.showToast({
                message: "Internal Cache Delete Success => " + this.data,
                duration: 2000
            });
        });
    }
    cleanInternalFiles() {
        this.index.cleanInternalFiles().then((path) => {
            this.data = path;
            _system_prompt_1.showToast({
                message: "Internal Files Delete Success: " + path,
                duration: 2000
            });
        });
    }
    cleanInternalSp() {
        this.index.cleanInternalSp().then((path) => {
            this.data = path;
            _system_prompt_1.showToast({
                message: "Shared Preference Delete Success => " + this.data,
                duration: 2000
            });
        });
    }
    cleanInternalDbByName(dbName) {
        if (dbName != null) {
            this.index.cleanInternalDbByName(dbName).then((name) => {
                _system_prompt_1.showToast({
                    message: "Database Delete Success => " + dbName,
                    duration: 2000
                });
            });
        }
        else {
            _system_prompt_1.showToast({
                message: "Database Delete Fail => No Database Name Entered",
                duration: 2000
            });
        }
    }
    cleanInternalDbs() {
        this.index.cleanInternalDbs().then((path) => {
            this.data = path;
            console.log("Internal Databases Cleaned: " + this.data);
            _system_prompt_1.showToast({
                message: "Internal Database Delete Success => " + this.data,
                duration: 2000
            });
        });
    }
    cleanCustomDir(dirName) {
        if (dirName != null) {
            this.index.cleanCustomDir(dirName).then((name) => {
                _system_prompt_1.showToast({
                    message: "Directory Clean Success => " + dirName,
                    duration: 2000
                });
            });
        }
        else {
            _system_prompt_1.showToast({
                message: "Directory Clean Fail => No Directory Path Entered",
                duration: 2000
            });
        }
    }
    render() {
        Column.create();
        Column.debugLine("pages/CleanUtilsSample.ets(138:5)");
        Row.create();
        Row.debugLine("pages/CleanUtilsSample.ets(139:7)");
        Row.height('50');
        Row.margin(10);
        Row.align(Alignment.Center);
        Text.create('CLEAN UTILS');
        Text.debugLine("pages/CleanUtilsSample.ets(140:9)");
        Text.fontSize(30);
        Text.fontColor(Color.Brown);
        Text.fontWeight(FontWeight.Bold);
        Text.pop();
        Row.pop();
        Row.create();
        Row.debugLine("pages/CleanUtilsSample.ets(146:7)");
        Row.height('50');
        Row.margin(10);
        Row.width(400);
        Flex.create({ alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center });
        Flex.debugLine("pages/CleanUtilsSample.ets(147:9)");
        Button.createWithLabel('Clean Cache', { type: ButtonType.Normal, stateEffect: true });
        Button.debugLine("pages/CleanUtilsSample.ets(148:11)");
        Button.onClick((event) => {
            this.cleanInternalCache();
        });
        Button.pop();
        Flex.pop();
        Row.pop();
        Row.create();
        Row.debugLine("pages/CleanUtilsSample.ets(154:7)");
        Row.height(50);
        Row.margin(10);
        Row.width(400);
        Flex.create({ alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center });
        Flex.debugLine("pages/CleanUtilsSample.ets(155:9)");
        Button.createWithLabel('Clean Files', { type: ButtonType.Normal, stateEffect: true });
        Button.debugLine("pages/CleanUtilsSample.ets(156:11)");
        Button.onClick((event) => {
            this.cleanInternalFiles();
        });
        Button.pop();
        Flex.pop();
        Row.pop();
        Row.create();
        Row.debugLine("pages/CleanUtilsSample.ets(162:7)");
        Row.height(50);
        Row.margin(10);
        Row.width(400);
        Flex.create({ alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center });
        Flex.debugLine("pages/CleanUtilsSample.ets(163:9)");
        Button.createWithLabel('Clean Shared Preferences', { type: ButtonType.Normal, stateEffect: true });
        Button.debugLine("pages/CleanUtilsSample.ets(164:11)");
        Button.onClick((event) => {
            this.cleanInternalSp();
        });
        Button.pop();
        Flex.pop();
        Row.pop();
        Row.create();
        Row.debugLine("pages/CleanUtilsSample.ets(171:7)");
        Row.height(50);
        Row.margin(5);
        Column.create();
        Column.debugLine("pages/CleanUtilsSample.ets(172:9)");
        Flex.create({ alignItems: ItemAlign.Center, justifyContent: FlexAlign.SpaceEvenly });
        Flex.debugLine("pages/CleanUtilsSample.ets(173:11)");
        TextInput.create({ placeholder: 'Database to be Cleaned' });
        TextInput.debugLine("pages/CleanUtilsSample.ets(174:13)");
        TextInput.type(InputType.Normal);
        TextInput.enterKeyType(EnterKeyType.Done);
        TextInput.id('dbName');
        TextInput.fontSize(1);
        TextInput.onChange((value) => {
            this.dbText = value;
        });
        TextInput.onSubmit((enterKey) => {
            console.log('Database name Submitted');
        });
        Button.createWithLabel('Clean the DataBase', { type: ButtonType.Normal, stateEffect: true });
        Button.debugLine("pages/CleanUtilsSample.ets(185:13)");
        Button.onClick((event) => {
            this.cleanInternalDbByName(this.dbText);
        });
        Button.borderWidth(2);
        Button.borderRadius(10);
        Button.pop();
        Flex.pop();
        Column.pop();
        Row.pop();
        Row.create();
        Row.debugLine("pages/CleanUtilsSample.ets(196:7)");
        Row.height(50);
        Row.margin(10);
        Row.width(400);
        Flex.create({ alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center });
        Flex.debugLine("pages/CleanUtilsSample.ets(197:9)");
        Button.createWithLabel('Clean all Internal DataBase', { type: ButtonType.Normal, stateEffect: true });
        Button.debugLine("pages/CleanUtilsSample.ets(198:11)");
        Button.onClick((event) => {
            this.cleanInternalDbs();
        });
        Button.pop();
        Flex.pop();
        Row.pop();
        Row.create();
        Row.debugLine("pages/CleanUtilsSample.ets(205:7)");
        Row.height(50);
        Row.margin(5);
        Column.create();
        Column.debugLine("pages/CleanUtilsSample.ets(206:9)");
        Flex.create({ alignItems: ItemAlign.Center, justifyContent: FlexAlign.SpaceEvenly });
        Flex.debugLine("pages/CleanUtilsSample.ets(207:11)");
        TextInput.create({ placeholder: 'Input Directory Path' });
        TextInput.debugLine("pages/CleanUtilsSample.ets(208:13)");
        TextInput.type(InputType.Normal);
        TextInput.enterKeyType(EnterKeyType.Done);
        TextInput.id('dbName');
        TextInput.fontSize(1);
        TextInput.onChange((value) => {
            this.dirText = value;
        });
        TextInput.onSubmit((enterKey) => {
            console.log('Directory Path Submitted');
        });
        Button.createWithLabel('Clean the Directory', { type: ButtonType.Normal, stateEffect: true });
        Button.debugLine("pages/CleanUtilsSample.ets(219:13)");
        Button.onClick((event) => {
            this.cleanCustomDir(this.dirText);
        });
        Button.borderWidth(2);
        Button.borderRadius(10);
        Button.pop();
        Flex.pop();
        Column.pop();
        Row.pop();
        Column.pop();
    }
}
loadDocument(new Index("1", undefined, {}));


/***/ }),

/***/ "../../../../../../../../DevEcoStudioProjects/OpenHarmonyUtilCode/utilcode/index.ets":
/*!*******************************************************************************************!*\
  !*** ../../../../../../../../DevEcoStudioProjects/OpenHarmonyUtilCode/utilcode/index.ets ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.CleanUtils = void 0;
/*
* Copyright (C) 2022 Application library engineering group.
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var CleanUtils_1 = __webpack_require__(/*! ./src/main/ets/utils/CleanUtils */ "../../../../../../../../DevEcoStudioProjects/OpenHarmonyUtilCode/utilcode/src/main/ets/utils/CleanUtils.ets");
Object.defineProperty(exports, "CleanUtils", ({ enumerable: true, get: function () { return CleanUtils_1.CleanUtils; } }));


/***/ }),

/***/ "../../../../../../../../DevEcoStudioProjects/OpenHarmonyUtilCode/utilcode/src/main/ets/utils/CleanUtils.ets":
/*!*******************************************************************************************************************!*\
  !*** ../../../../../../../../DevEcoStudioProjects/OpenHarmonyUtilCode/utilcode/src/main/ets/utils/CleanUtils.ets ***!
  \*******************************************************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.CleanUtils = void 0;
/*
* Copyright (C) 2022 Application library engineering group.
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var _ohos_ability_featureAbility_1  = globalThis.requireNapi('ability.featureAbility') || (isSystemplugin('ability.featureAbility', 'ohos') ? globalThis.ohosplugin.ability.featureAbility : isSystemplugin('ability.featureAbility', 'system') ? globalThis.systemplugin.ability.featureAbility : undefined);
var _ohos_fileio_1  = globalThis.requireNapi('fileio') || (isSystemplugin('fileio', 'ohos') ? globalThis.ohosplugin.fileio : isSystemplugin('fileio', 'system') ? globalThis.systemplugin.fileio : undefined);
__webpack_require__(/*! @system.file */ "../../api/@system.file.d.ts");
var _ohos_data_storage_1  = globalThis.requireNapi('data.storage') || (isSystemplugin('data.storage', 'ohos') ? globalThis.ohosplugin.data.storage : isSystemplugin('data.storage', 'system') ? globalThis.systemplugin.data.storage : undefined);
var _ohos_data_rdb_1  = globalThis.requireNapi('data.rdb') || (isSystemplugin('data.rdb', 'ohos') ? globalThis.ohosplugin.data.rdb : isSystemplugin('data.rdb', 'system') ? globalThis.systemplugin.data.rdb : undefined);
var _ohos_bundle_1  = globalThis.requireNapi('bundle') || (isSystemplugin('bundle', 'ohos') ? globalThis.ohosplugin.bundle : isSystemplugin('bundle', 'system') ? globalThis.systemplugin.bundle : undefined);
const STORE_CONFIG = "book.db";
let rdbStore = undefined;
class CleanUtils {
    constructor() {
    }
    async cleanInternalCache() {
        var context = _ohos_ability_featureAbility_1.getContext();
        var path;
        context.getCacheDir((error, data) => {
            if (error) {
                console.error('Failed to obtain Cache Directory. Cause: ' + error.message);
                return error.message;
            }
            console.info('Cache directory Obtained. Data: ' + JSON.stringify(data));
            path = data;
            _ohos_fileio_1.rmdirSync(data);
        });
        return path;
    }
    async cleanInternalFiles() {
        var path;
        var context = _ohos_ability_featureAbility_1.getContext();
        context.getFilesDir((error, data) => {
            if (error) {
                console.error('Failed to obtain the file directory. Cause: ' + error.message + 'Code: ' + error.code);
                return error.message;
            }
            console.info('File directory Obtained. Data: ' + JSON.stringify(data));
            path = data;
            console.log(path);
            _ohos_fileio_1.rmdirSync(path);
        });
        return path;
    }
    async cleanInternalSp() {
        var context = _ohos_ability_featureAbility_1.getContext();
        var path;
        context.getFilesDir((error, data) => {
            if (error) {
                console.error('Failed to obtain File Directory. Cause: ' + JSON.stringify(error));
                return JSON.stringify(error);
            }
            console.info('File directory Obtained. Data: ' + JSON.stringify(data));
            console.info(data);
            path = data + '/sharedPreference';
            _ohos_data_storage_1.deleteStorage(path, function (err) {
                if (err) {
                    console.info("Shared Preference Delete Failed" + err);
                    return;
                }
                console.info("Shared Preference Delete Success");
            });
        });
        return path;
    }
    async cleanInternalDbByName(dbName) {
        if (dbName == null) {
            console.error("No Database Name Entered");
            return "Enter Database Name";
        }
        else {
            _ohos_data_rdb_1.deleteRdbStore(this, dbName, function (err, rdbStore) {
                console.info('Database Delete Success: =>' + dbName);
            });
            return dbName;
        }
    }
    async cleanInternalDbs() {
        var dbPath;
        let bundleName = "com.example.cleanutilsets_1";
        let bundleFlags = 0;
        _ohos_bundle_1.getApplicationInfo(bundleName, bundleFlags, (err, data) => {
            if (err) {
                console.error('Application Information fetch failed. Cause: ' + JSON.stringify(err));
                return;
            }
            console.info('Application Information fetched successfully. Data:' + JSON.stringify(data));
            dbPath = data.entryDir + '/database';
            console.log('DB Directory: ' + dbPath);
            _ohos_fileio_1.rmdirSync(dbPath);
        });
        return dbPath;
    }
    async cleanCustomDir(dirPath) {
        _ohos_fileio_1.rmdirSync(dirPath);
        return dirPath;
    }
}
exports.CleanUtils = CleanUtils;


/***/ }),

/***/ "../../api/@system.file.d.ts":
/*!***********************************!*\
  !*** ../../api/@system.file.d.ts ***!
  \***********************************/
/***/ (() => {



/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		var commonCachedModule = globalThis["__common_module_cache__"] ? globalThis["__common_module_cache__"][moduleId]: null;
/******/ 		if (commonCachedModule) { return commonCachedModule.exports; }
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		if (globalThis["__common_module_cache__"] && moduleId.indexOf("?name=") < 0 && Object.keys(globalThis["__common_module_cache__"]).indexOf(moduleId) >= 0) {
/******/ 		  globalThis["__common_module_cache__"][moduleId] = module;
/******/ 		}
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__("../../../../../../../../DevEcoStudioProjects/OpenHarmonyUtilCode/entry/src/main/ets/MainAbility/pages/CleanUtilsSample.ets?entry");
/******/ 	
/******/ })()
;
//# sourceMappingURL=CleanUtilsSample.js.map