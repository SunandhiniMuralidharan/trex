/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "../../../../../../../../DevEcoStudioProjects/OpenHarmonyUtilCode/entry/src/main/ets/MainAbility/pages/index.ets?entry":
/*!*****************************************************************************************************************************!*\
  !*** ../../../../../../../../DevEcoStudioProjects/OpenHarmonyUtilCode/entry/src/main/ets/MainAbility/pages/index.ets?entry ***!
  \*****************************************************************************************************************************/
/***/ (function(__unused_webpack_module, exports) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
/*
* Copyright (C) 2022 Application library engineering group.
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var _system_router_1  = globalThis.requireNativeModule('system.router');
class Index extends View {
    constructor(compilerAssignedUniqueChildId, parent, params) {
        super(compilerAssignedUniqueChildId, parent);
        this.updateWithValueParams(params);
    }
    updateWithValueParams(params) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id());
    }
    render() {
        Row.create();
        Row.debugLine("pages/index.ets(22:5)");
        Row.height('100%');
        Column.create();
        Column.debugLine("pages/index.ets(23:7)");
        Column.width('100%');
        Button.createWithLabel('Clean Utils');
        Button.debugLine("pages/index.ets(24:9)");
        Button.width(400);
        Button.height(50);
        Button.onClick(() => _system_router_1.push({ uri: "pages/CleanUtilsSample" }));
        Button.pop();
        Column.pop();
        Row.pop();
    }
}
loadDocument(new Index("1", undefined, {}));


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["../../../../../../../../DevEcoStudioProjects/OpenHarmonyUtilCode/entry/src/main/ets/MainAbility/pages/index.ets?entry"](0, __webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=index.js.map